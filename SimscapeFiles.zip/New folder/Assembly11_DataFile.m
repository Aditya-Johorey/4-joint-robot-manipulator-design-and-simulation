% Simscape(TM) Multibody(TM) version: 24.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(9).translation = [0.0 0.0 0.0];
smiData.RigidTransform(9).angle = 0.0;
smiData.RigidTransform(9).axis = [0.0 0.0 0.0];
smiData.RigidTransform(9).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 23.622047244094485];  % in
smiData.RigidTransform(1).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(1).axis = [2.8150207811241669e-16 -2.5585440121553339e-16 1];
smiData.RigidTransform(1).ID = "B[Part1a:1:-:Part1b:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0 0 -19.685039370078737];  % in
smiData.RigidTransform(2).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(2).axis = [0 0 1];
smiData.RigidTransform(2).ID = "F[Part1a:1:-:Part1b:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0 0 -19.685039370078737];  % in
smiData.RigidTransform(3).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(3).axis = [0 1 0];
smiData.RigidTransform(3).ID = "B[Part1b:1:-:Part2:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [0 0 3.9370078740157477];  % in
smiData.RigidTransform(4).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(4).axis = [0 1 0];
smiData.RigidTransform(4).ID = "F[Part1b:1:-:Part2:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-22.118244050196438 1.9685039370078745 1.9685039370078738];  % in
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = "B[Part2:1:-:Part3:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [13.385826771653539 -1.9685039370078738 1.9685039370078738];  % in
smiData.RigidTransform(6).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(6).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(6).ID = "F[Part2:1:-:Part3:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [-13.779527559055117 -6.9935308637805131e-16 1.9685039370078738];  % in
smiData.RigidTransform(7).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(7).axis = [8.8708992217261639e-17 -1 8.8708992217261639e-17];
smiData.RigidTransform(7).ID = "B[Part3:1:-:Part4:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [0 0 0];  % in
smiData.RigidTransform(8).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(8).axis = [-0 -1 -0];
smiData.RigidTransform(8).ID = "F[Part3:1:-:Part4:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-13.621452660954859 -3.145965226765826 -4.3930770809157371];  % in
smiData.RigidTransform(9).angle = 8.8337491891070891e-16;  % rad
smiData.RigidTransform(9).axis = [0.90469263269358535 0.12121238470119003 0.40845905320484699];
smiData.RigidTransform(9).ID = "RootGround[Part1a:1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(5).mass = 0.0;
smiData.Solid(5).CoM = [0.0 0.0 0.0];
smiData.Solid(5).MoI = [0.0 0.0 0.0];
smiData.Solid(5).PoI = [0.0 0.0 0.0];
smiData.Solid(5).color = [0.0 0.0 0.0];
smiData.Solid(5).opacity = 0.0;
smiData.Solid(5).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 41.186812540743688;  % kg
smiData.Solid(1).CoM = [1.5234317359608113e-08 -2.8265193309574998e-14 467.8314512100502];  % mm
smiData.Solid(1).MoI = [5099437.6645996766 5099437.6373651521 321025.60073597619];  % kg*mm^2
smiData.Solid(1).PoI = [2.0043057015858335e-10 0.00016815045372383953 -5.5879354478702225e-10];  % kg*mm^2
smiData.Solid(1).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "Part1a.ipt_{A4A4EB07-47D6-DF13-906D-71ADF6D58B2D}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 23.954643983621899;  % kg
smiData.Solid(2).CoM = [1.0971001073978441e-08 -4.8598226676434633e-14 -362.29508196721747];  % mm
smiData.Solid(2).MoI = [2927529.7460778365 2927529.7298486931 352079.26232093555];  % kg*mm^2
smiData.Solid(2).PoI = [-3.2329107405708933e-10 -0.00010178488732666868 -5.5879354478205907e-10];  % kg*mm^2
smiData.Solid(2).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "Part1b.ipt_{D60FA37A-4ED1-B87A-A1E1-DE8BD1E7FB21}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 9.5514410848524776;  % kg
smiData.Solid(3).CoM = [-255.92671069507935 1.828237029251375e-13 49.999999961219785];  % mm
smiData.Solid(3).MoI = [55860.686480403601 308137.39181270968 347856.206839928];  % kg*mm^2
smiData.Solid(3).PoI = [-2.9103830524452874e-11 8.7860762141644949e-05 -5.4003911330669533e-10];  % kg*mm^2
smiData.Solid(3).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "Part2.ipt_{47703B18-4BE1-B899-EA3C-6487C60E16BE}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 12.327252841225985;  % kg
smiData.Solid(4).CoM = [37.615348554339917 -0.021285105009505225 50.011475706455059];  % mm
smiData.Solid(4).MoI = [46812.314577825877 446103.53252778185 473436.9990805065];  % kg*mm^2
smiData.Solid(4).PoI = [6.7635762130478669 -39.592305363976635 65.695465252388388];  % kg*mm^2
smiData.Solid(4).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "Part3.ipt_{DD260608-4529-249F-45DC-9FB69FF6D94A}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 15.404628033189967;  % kg
smiData.Solid(5).CoM = [-271.16656971677776 -1.8892913476409936e-14 11.373946890090849];  % mm
smiData.Solid(5).MoI = [140960.83428199025 598800.4284943575 562545.13540143322];  % kg*mm^2
smiData.Solid(5).PoI = [-3.3102542191309766e-12 -106406.7375943873 -1.4212398755836272e-11];  % kg*mm^2
smiData.Solid(5).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "Part4.ipt_{42BEDE3E-4737-277F-4DCC-04831C0BD9DB}";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(1).Rz.Pos = 0.0;
smiData.CylindricalJoint(1).Pz.Pos = 0.0;
smiData.CylindricalJoint(1).ID = "";

smiData.CylindricalJoint(1).Rz.Pos = 109.86038635957186;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0.76249739761530577;  % in
smiData.CylindricalJoint(1).ID = "[Part1a:1:-:Part1b:1]";


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(3).Rz.Pos = 0.0;
smiData.RevoluteJoint(3).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -69.962769910944758;  % deg
smiData.RevoluteJoint(1).ID = "[Part1b:1:-:Part2:1]";

smiData.RevoluteJoint(2).Rz.Pos = -145.16564427884259;  % deg
smiData.RevoluteJoint(2).ID = "[Part2:1:-:Part3:1]";

smiData.RevoluteJoint(3).Rz.Pos = -179.9052655626829;  % deg
smiData.RevoluteJoint(3).ID = "[Part3:1:-:Part4:1]";

